public enum tipoAcervo {
    FILME,VIDEOGAME,MUSICA;
}
