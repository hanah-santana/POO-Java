public enum tipoMidia {
    DVD,CD,FITA;
}
