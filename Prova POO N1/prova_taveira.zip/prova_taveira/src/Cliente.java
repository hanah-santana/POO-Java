public class Cliente {
    private int id;
    private String codigo;
    private String nome;
    private String endereco;
    private String telefone;
    private String bairro;
    private String CEP;
    Emprestimo e;

    public Cliente(int id, String codigo, String nome, String endereco, String telefone, String bairro, String CEP, Emprestimo e) {
        this.id = id;
        this.codigo = codigo;
        this.nome = nome;
        this.endereco = endereco;
        this.telefone = telefone;
        this.bairro = bairro;
        this.CEP = CEP;
        this.e = e;
    }

    public Emprestimo getE() {
        return e;
    }

    public void setE(Emprestimo e) {
        this.e = e;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getCEP() {
        return CEP;
    }

    public void setCEP(String CEP) {
        this.CEP = CEP;
    }

    public void nota(){
        System.out.println("Nome: "+getNome());
        System.out.println("Código do cliente: "+getCodigo());
        System.out.println("Endereco: "+getEndereco());
        System.out.println("Valor da compra: "+getE().valorEmprestimo());
        for (itemEmprestimo item: this.e.itpd){
            System.out.println(item.getItens());
        }

    }
}
