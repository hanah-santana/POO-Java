import java.util.*;
public class itemEmprestimo {
    private int id;
    private float valor;
    private Exemplar ex1;
    ArrayList<Float> itens = new ArrayList<Float>();

    public float getValor() {
        return valor;
    }

    public ArrayList<Float> getItens() {
        return itens;
    }

    public void setItens(ArrayList<Float> itens) {
        this.itens = itens;
    }

    public int getId() {
        return id;
    }

    public itemEmprestimo(int id, float valor, Exemplar ex1) {
        this.id = id;
        this.valor = valor;
        this.ex1 = ex1;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setValor(float valor) {
        this.valor = valor;
    }

    public Exemplar getEx1() {
        return ex1;
    }

    public void setEx1(Exemplar ex1) {
        this.ex1 = ex1;
    }

    public void add(itemEmprestimo item,Exemplar ex){
        float valor = 0;
        valor += item.ex1.getA().getValor();
        this.itens.add(valor);
    }

}
