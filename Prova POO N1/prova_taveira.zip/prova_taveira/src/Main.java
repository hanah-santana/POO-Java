public class Main {
    public static void main(String[] args) {
        Acervo a1 = new Acervo(01,"001","As trancas do rei careca",10.0f,tipoClassificacao.LANCAMENTO);
        Acervo a2 = new Acervo(02,"002","A volta dos que não foram",12.0f,tipoClassificacao.LANCAMENTO);
        Acervo a3 = new Acervo(03,"003","Fui, mas nao fui, quando eu vi já tava lá",14.0f,tipoClassificacao.LANCAMENTO);
        Exemplar ex1 = new Exemplar(01,001,"12/09/2001",a1);
        Exemplar ex2 = new Exemplar(02,002,"12/09/2001",a2);
        Exemplar ex3 = new Exemplar(03,003,"12/09/2001",a3);
        itemEmprestimo it1 = new itemEmprestimo(001,a1.getValor(),ex1);
        itemEmprestimo it2 = new itemEmprestimo(002,a1.getValor(),ex2);
        itemEmprestimo it3 = new itemEmprestimo(003,a1.getValor(),ex3);
        it1.add(it1,ex1);
        it1.add(it2,ex2);
        it1.add(it3,ex3);
        Emprestimo e1 = new Emprestimo(001,"1234","10/04/2019","02/04/2019","13/04/2019");
        Cliente c1 = new Cliente(001,"2252121","Rua Paraná","Rua Paraná","(85)99999-9999","José Walter","00000-000",e1);
        c1.nota();



    }
}
