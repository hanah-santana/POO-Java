import java.util.ArrayList;
public class Emprestimo {
    private int id;
    private String codigo;
    private String dataEntregaPrevista;
    private String dataEmprestimo;
    private String dataEntrega;
    private float ValorEmprestimo;
    private float valorMulta;
    private float valorTotal;
    private itemEmprestimo ite1;
    ArrayList<itemEmprestimo> itpd = new ArrayList<>();

    public float valorEmprestimo(){
        float valor = 0;
        for (itemEmprestimo it: itpd) {
            valor += it.getValor();
        }
        return valor;
    }

    public Emprestimo(int id, String codigo, String dataEntregaPrevista, String dataEmprestimo, String dataEntrega) {
        this.id = id;
        this.codigo = codigo;
        this.dataEntregaPrevista = dataEntregaPrevista;
        this.dataEmprestimo = dataEmprestimo;
        this.dataEntrega = dataEntrega;
    }

    public String getDataEntregaPrevista() {
        return dataEntregaPrevista;
    }

    public void setDataEntregaPrevista(String dataEntregaPrevista) {
        this.dataEntregaPrevista = dataEntregaPrevista;
    }

    public String getDataEmprestimo() {
        return dataEmprestimo;
    }

    public void setDataEmprestimo(String dataEmprestimo) {
        this.dataEmprestimo = dataEmprestimo;
    }

    public String getDataEntrega() {
        return dataEntrega;
    }

    public void setDataEntrega(String dataEntrega) {
        this.dataEntrega = dataEntrega;
    }

    public ArrayList<itemEmprestimo> getItpd() {
        return itpd;
    }

    public void setItpd(ArrayList<itemEmprestimo> itpd) {
        this.itpd = itpd;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public float getValorEmprestimo() {
        return ValorEmprestimo;
    }

    public void setValorEmprestimo(float valorEmprestimo) {
        ValorEmprestimo = valorEmprestimo;
    }

    public float getValorMulta() {
        return valorMulta;
    }

    public void setValorMulta(float valorMulta) {
        this.valorMulta = valorMulta;
    }

    public float getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(float valorTotal) {
        this.valorTotal = valorTotal;
    }


}
