public class Acervo {
    private int id;
    private String codigo;
    private String titulo;
    private float valor;
    tipoAcervo tipoAcervo;
    tipoMidia tipoMidia;
    tipoClassificacao tipoClassificacao;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public float getValor() {
        return valor;
    }

    public void setValor(float valor) {
        this.valor = valor;
    }

    public Acervo(int id, String codigo, String titulo, float valor,tipoAcervo tipoAcervo) {
        this.id = id;
        this.codigo = codigo;
        this.titulo = titulo;
        this.valor = valor;
        this.tipoAcervo = tipoAcervo;
    }
    public Acervo(int id, String codigo, String titulo, float valor,tipoMidia tipoMidia) {
        this.id = id;
        this.codigo = codigo;
        this.titulo = titulo;
        this.valor = valor;
        this.tipoMidia = tipoMidia;
    }

    public tipoAcervo getTipoAcervo() {
        return tipoAcervo;
    }

    public void setTipoAcervo(tipoAcervo tipoAcervo) {
        this.tipoAcervo = tipoAcervo;
    }

    public tipoMidia getTipoMidia() {
        return tipoMidia;
    }

    public void setTipoMidia(tipoMidia tipoMidia) {
        this.tipoMidia = tipoMidia;
    }

    public tipoClassificacao getTipoClassificacao() {
        return tipoClassificacao;
    }

    public void setTipoClassificacao(tipoClassificacao tipoClassificacao) {
        this.tipoClassificacao = tipoClassificacao;
    }

    public Acervo(int id, String codigo, String titulo, float valor, tipoClassificacao tipoClassificacao) {
        this.id = id;
        this.codigo = codigo;
        this.titulo = titulo;
        this.valor = valor;
        this.tipoClassificacao = tipoClassificacao;
    }

}
