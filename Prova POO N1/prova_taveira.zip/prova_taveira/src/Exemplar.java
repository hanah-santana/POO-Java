import java.lang.reflect.Array;
import java.util.*;

public class Exemplar {
    private int id;
    private int sequencial;
    private String dataRegistro;
    private Acervo a;
    ArrayList<Float> item = new ArrayList<Float>();

    public void add(itemEmprestimo itens){
        this.item.add(a.getValor());
    }

    public Exemplar(int id, int sequencial, String dataRegistro, Acervo a) {
        this.id = id;
        this.sequencial = sequencial;
        this.dataRegistro = dataRegistro;
        this.a = a;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getSequencial() {
        return sequencial;
    }

    public void setSequencial(int sequencial) {
        this.sequencial = sequencial;
    }

    public String getDataRegistro() {
        return dataRegistro;
    }

    public void setDataRegistro(String dataRegistro) {
        this.dataRegistro = dataRegistro;
    }

    public Acervo getA() {
        return a;
    }

    public void setA(Acervo a) {
        this.a = a;
    }
}
