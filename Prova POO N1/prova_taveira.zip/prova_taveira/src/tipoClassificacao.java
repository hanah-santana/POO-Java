public enum tipoClassificacao {
    LANCAMENTO,OURO,PRATA,BRONZE;
}
